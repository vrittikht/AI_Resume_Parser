import json
import spacy

def convert_labelstudio_to_spacy(input_file, output_file):
    nlp = spacy.blank("en")  # Needed to validate alignment

    with open(input_file, 'r', encoding='utf-8') as f:
        data = json.load(f)

    training_data = []

    for item in data:
        text = item['data']['text']
        ents = []

        for annotation in item['annotations']:
            for result in annotation['result']:
                start = result['value']['start']
                end = result['value']['end']
                label = result['value']['labels'][0].upper()

                span_text = text[start:end]
                doc = nlp.make_doc(text)
                span = doc.char_span(start, end, label=label)

                # Check if the span is valid and not overlapping
                if span is not None:
                    overlap = any(start < existing[1] and end > existing[0] for existing in ents)
                    if not overlap:
                        ents.append((start, end, label))
                else:
                    print(f"[!] Skipped misaligned entity: '{span_text}' ({start}, {end})")

        if ents:
            training_data.append((text, {"entities": ents}))

    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(training_data, f, indent=4)

    print(f"[✓] Saved clean training data to {output_file}")

# Example usage
convert_labelstudio_to_spacy(
    input_file='project-2-at-2025-07-13-22-29-94541520.json',
    output_file='train_data.json'
)
