import spacy

def load_model(model_path):
    return spacy.load(model_path)

def extract_entities(text, model):
    doc = model(text)
    return [(ent.text, ent.label_) for ent in doc.ents]

# Example usage
model = load_model("output_model")
text = "ABHIJIT MEHARE Contact - +91-9970101574 Email- abhijitmehare11@gmail.com"
print(extract_entities(text, model))
