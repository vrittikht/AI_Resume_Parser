from parser import extract_text
import os

# Paths
input_folder = r'D:\vritti khatri\resumes'  # Folder with your .pdf, .docx, .jpg files
output_folder = "resume_texts/"  # Where .txt files will be saved

os.makedirs(output_folder, exist_ok=True)

# Convert each file
for file in os.listdir(input_folder):
    file_path = os.path.join(input_folder, file)

    if os.path.isfile(file_path):
        try:
            text = extract_text(file_path)
            if text.strip():  # skip empty files
                output_filename = os.path.splitext(file)[0] + ".txt"
                output_path = os.path.join(output_folder, output_filename)
                with open(output_path, "w", encoding="utf-8") as f:
                    f.write(text)
                print(f"[✓] Converted: {file} → {output_filename}")
            else:
                print(f"[!] Skipped (empty): {file}")
        except Exception as e:
            print(f"[✗] Failed to convert {file}: {e}")
