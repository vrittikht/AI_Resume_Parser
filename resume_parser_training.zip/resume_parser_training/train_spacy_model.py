import spacy
from spacy.training.example import Example
import json
import random
from pathlib import Path

def load_training_data(path):
    with open(path, 'r', encoding='utf-8') as f:
        training_data = json.load(f)
    return training_data

def train_ner(train_data_path, output_dir):
    TRAIN_DATA = load_training_data(train_data_path)

    nlp = spacy.blank("en")
    ner = nlp.add_pipe("ner")

    # Add custom labels
    for _, annotations in TRAIN_DATA:
        for ent in annotations.get("entities"):
            ner.add_label(ent[2])

    # Training loop
    optimizer = nlp.begin_training()
    for i in range(30):
        random.shuffle(TRAIN_DATA)
        losses = {}
        for text, annotations in TRAIN_DATA:
            doc = nlp.make_doc(text)
            example = Example.from_dict(doc, annotations)
            nlp.update([example], drop=0.3, losses=losses)
        print(f"Epoch {i+1} Losses", losses)

    # Save the model
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    nlp.to_disk(output_dir)
    print(f"[✓] Model trained and saved to {output_dir}")

# Example usage
train_ner("train_data.json", "output_model")
